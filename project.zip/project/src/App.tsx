import React, { useState, useEffect } from 'react';
import { StoreProvider } from './lib/store';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Catalog } from './components/Catalog';
import { CartDrawer } from './components/CartDrawer';
import { Footer } from './components/Footer';
import { translations } from './lib/translations';

export default function App() {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isArabic, setIsArabic] = useState(true);

  const t = isArabic ? translations.ar : translations.en;

  useEffect(() => {
    document.documentElement.dir = isArabic ? 'rtl' : 'ltr';
    document.documentElement.lang = isArabic ? 'ar' : 'en';
  }, [isArabic]);

  return (
    <StoreProvider>
      <div className="min-h-screen bg-[#0A3225] text-[#D4AF37]">
        {/* شريط علوي للتحويل بين العربي والإنجليزي */}
        <div className="bg-[#062218] px-6 py-2 border-b border-[#D4AF37]/20 flex justify-between items-center text-sm">
          <span>{t.welcome}</span>
          <button
            onClick={() => setIsArabic(!isArabic)}
            className="px-3 py-1 border border-[#D4AF37] rounded hover:bg-[#D4AF37] hover:text-[#0A3225] transition"
          >
            {isArabic ? 'English' : 'العربية'}
          </button>
        </div>

        <Navbar
          onOpenCart={() => setIsCartOpen(true)}
          onOpenWishlist={() => {}}
          onSearch={setSearchQuery}
          query={searchQuery}
        />

        <Hero />

        <Catalog
          query={searchQuery}
          categoryFilter={selectedCategory}
          setCategoryFilter={setSelectedCategory}
          onView={() => {}}
        />

        <Footer onAdminAccess={() => {}} />

        <CartDrawer
          open={isCartOpen}
          onClose={() => setIsCartOpen(false)}
          onCheckout={() => {}}
        />
      </div>
    </StoreProvider>
  );
}