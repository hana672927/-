import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Sparkles } from 'lucide-react';
import { useStore } from '@/lib/store';

interface FooterProps {
  onAdminAccess: () => void;
}

export function Footer({ onAdminAccess }: FooterProps) {
  const { content } = useStore();

  return (
    <footer id="contact" className="bg-obsidian border-t border-gold-300/15 pt-20 pb-8 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-4 gap-12 mb-16">
          {/* brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-gold-300" />
              <span className="font-serif text-2xl gold-text">{content.footer_brand}</span>
            </div>
            <p className="text-cream/50 max-w-sm leading-relaxed mb-6">{content.footer_tagline}</p>
            <div className="flex gap-3">
              {['IG', 'FB', 'PIN'].map((s) => (
                <a key={s} href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center text-gold-300 text-xs tracking-wider hover:border-gold-300/50 transition-all">
                  {s}
                </a>
              ))}
            </div>
          </div>

          {/* contact */}
          <div>
            <h4 className="text-gold-300 text-xs tracking-widest uppercase mb-5">Contact</h4>
            <ul className="space-y-3 text-cream/60 text-sm">
              <li className="flex items-center gap-3"><Mail className="w-4 h-4 text-gold-300/70" /> {content.footer_email}</li>
              <li className="flex items-center gap-3"><Phone className="w-4 h-4 text-gold-300/70" /> {content.footer_phone}</li>
              <li className="flex items-center gap-3"><MapPin className="w-4 h-4 text-gold-300/70" /> {content.footer_address}</li>
            </ul>
          </div>

          {/* policies */}
          <div>
            <h4 className="text-gold-300 text-xs tracking-widest uppercase mb-5">Client Care</h4>
            <ul className="space-y-3 text-cream/60 text-sm">
              <li><a href="#" className="hover:text-gold-200 transition-colors">Shipping & Delivery</a></li>
              <li><a href="#" className="hover:text-gold-200 transition-colors">Returns</a></li>
              <li><a href="#" className="hover:text-gold-200 transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-gold-200 transition-colors">FAQ</a></li>
            </ul>
          </div>
        </div>

        {/* policy text expandable */}
        <div className="grid md:grid-cols-3 gap-6 mb-12 text-cream/40 text-xs leading-relaxed">
          <div className="glass rounded-xl p-4"><strong className="text-gold-300/80 block mb-2 tracking-wider uppercase text-[10px]">Shipping</strong>{content.policy_shipping}</div>
          <div className="glass rounded-xl p-4"><strong className="text-gold-300/80 block mb-2 tracking-wider uppercase text-[10px]">Returns</strong>{content.policy_returns}</div>
          <div className="glass rounded-xl p-4"><strong className="text-gold-300/80 block mb-2 tracking-wider uppercase text-[10px]">Privacy</strong>{content.policy_privacy}</div>
        </div>

        <div className="border-t border-gold-300/10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-cream/40 text-xs">{content.footer_copyright}</p>
          {/* hidden admin access */}
          <button
            onClick={onAdminAccess}
            className="text-cream/20 hover:text-gold-300/60 text-[10px] tracking-widest uppercase transition-colors duration-300"
            aria-label="Admin access"
            title="Admin"
          >
            © {content.footer_brand} — Admin Access
          </button>
        </div>
      </div>
    </footer>
  );
}
