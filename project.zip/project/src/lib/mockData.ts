import type { Product, SiteContentMap, SiteAssetMap } from './types';

export const MOCK_PRODUCTS: Product[] = [
  { id: 'm1', title: 'Emerald Nocturne', price: 320, description: 'عطر عميق ومخملي يعتمد على العود الجبلي والعنبر المدخن. يلتف حولك كالحرير الليلي.', top_notes: 'Bergamot, Pink Pepper', mid_notes: 'Black Rose, Saffron', base_notes: 'Oud, Amber, Sandalwood', in_stock: true, category: 'Niche', featured: true, sort_order: 1, images: [] },
  { id: 'm2', title: 'Gilded Forest', price: 280, description: 'أشعة الشمس التي تتخلل أشجار الغابات القديمة — حمضيات مشرقة مع الأرز الدافئ.', top_notes: 'Neroli, Grapefruit', mid_notes: 'Fig, Cypress', base_notes: 'Cedar, Vetiver, Oakmoss', in_stock: true, category: 'Niche', featured: true, sort_order: 2, images: [] },
  { id: 'm3', title: 'Royal Oud Reserve', price: 540, description: 'أثمن أنواع العود لدينا، معتق لسبع سنوات وممزوج بالورد والجلد الفاخر.', top_notes: 'Saffron, Cardamom', mid_notes: 'Taif Rose, Jasmine', base_notes: 'Aged Oud, Leather, Musk', in_stock: true, category: 'Oud', featured: true, sort_order: 3, images: [] },
  { id: 'm4', title: 'Amber Whisper EDP', price: 195, description: 'عطر دافئ ولمس حسي من سحلية الفانيليا والتونكا والعنبر الذهبي.', top_notes: 'Mandarin, Pear', mid_notes: 'Vanilla Orchid, Heliotrope', base_notes: 'Amber, Tonka, Benzoin', in_stock: true, category: 'EDP', featured: false, sort_order: 4, images: [] },
  { id: 'm5', title: 'Velvet Rose EDP', price: 210, description: 'باقة من الورود الداكنة مع لمسات من البخور والباتشولي.', top_notes: 'Blackcurrant, Lychee', mid_notes: 'Bulgarian Rose, Geranium', base_notes: 'Patchouli, Frankincense', in_stock: true, category: 'EDP', featured: true, sort_order: 5, images: [] },
  { id: 'm6', title: 'Desert Bloom Oil', price: 120, description: 'زيت عطري مركز من الياسمين والتمر والصمغ الدافئ. خالي من الكحول.', top_notes: 'Jasmine Sambac', mid_notes: 'Date, Orange Blossom', base_notes: 'Labdanum, Myrrh', in_stock: true, category: 'Oil Perfumes', featured: false, sort_order: 6, images: [] },
  { id: 'm7', title: 'Nightingale Oil', price: 140, description: 'زيت معتق من البرقوق والعسل الداكن وخشب الجاكياك المدخن.', top_notes: 'Plum', mid_notes: 'Honey, Iris', base_notes: 'Guaiac Wood, Tonka', in_stock: true, category: 'Oil Perfumes', featured: false, sort_order: 7, images: [] },
  { id: 'm8', title: 'The Gift Set Collection', price: 380, description: 'ثلاثة بخاخات سفر سعة 10 مل من أكثر عطورنا مبيعاً في صندوق هدايا فاخر.', top_notes: 'Assorted', mid_notes: 'Assorted', base_notes: 'Assorted', in_stock: true, category: 'Gift Sets', featured: true, sort_order: 8, images: [] },
  { id: 'm9', title: 'Summer Azure', price: 165, description: 'عطر مائي منعش من ملح البحر والمسك الأبيض وأوراق التين الدافئة.', top_notes: 'Sea Salt, Lemon', mid_notes: 'Fig Leaf, Lavender', base_notes: 'White Musk, Driftwood', in_stock: true, category: 'Summer', featured: true, sort_order: 9, images: [] },
  { id: 'm10', title: 'Winter Ember', price: 230, description: 'دفء الحطب المشتعل مع القرفة والتبغ وشمع العسل لليالي الباردة.', top_notes: 'Cinnamon, Orange Peel', mid_notes: 'Tobacco, Clove', base_notes: 'Beeswax, Vanilla, Styrax', in_stock: true, category: 'Winter', featured: true, sort_order: 10, images: [] },
];

export const MOCK_CONTENT: SiteContentMap = {
  hero_headline: 'جوهر الفخامة',
  hero_subtitle: 'عطور نادرة مصنوعة يدوياً من أجود الزيوت والعود العالمي. عبير يروي كل حكاية.',
  hero_cta: 'اكتشف المجموعة',
  announcement: 'شحن مجاني لجميع الطلبات التي تتجاوز $200 — توصيل لجميع أنحاء العالم',
  about_title: 'فن صناعة العطور',
  about_body: 'من شغفنا بالندرة والإتقان، تصاغ عطورنا لتبقى حية في الذاكرة. كل زجاجة هي معزوفة بلمسة كبار العطارين.',
  about_stat1_value: '42',
  about_stat1_label: 'عطراً فريداً',
  about_stat2_value: '18',
  about_stat2_label: 'دولة حول العالم',
  about_stat3_value: '100%',
  about_stat3_label: 'مكونات طبيعية',
  collection_title: 'المجموعة المتميزة',
  collection_subtitle: 'استكشف عائلاتنا العطرية الفاخرة',
  footer_brand: 'Maison Verdor',
  footer_tagline: 'عطور فاخرة مصممة من قلب الطبيعة',
  footer_email: 'concierge@verdor.com',
  footer_phone: '+1 (800) 555-0199',
  footer_address: '1 Rue des Essences, Grasse, France',
  footer_copyright: '© 2026 Maison Verdor. جميع الحقوق محفوظة.',
  policy_shipping: 'نشحن إلى جميع أنحاء العالم مع تأمين شامل. يتم شحن الطلبات خلال 48 ساعة للوصول في غضون 3-7 أيام عمل.',
  policy_returns: 'يمكن إرجاع الزجاجات غير المفتوحة خلال 14 يوماً لاسترداد المبلغ بالكامل.',
  policy_privacy: 'نجمع البيانات الضرورية فقط لإتمام طلبك ولن نشارك بياناتك مطلقاً.',
  button_shop_now: 'تسوق الآن',
  button_add_to_cart: 'أضف إلى السلة',
  button_checkout: 'إتمام الشراء',
  button_view_all: 'عرض الكل',
  categories_title: 'العائلات العطرية',
};

export const MOCK_ASSETS: SiteAssetMap = {
  hero_background: '',
  hero_bottle: '',
  about_image: '',
  banner_promo: '',
  cover_niche: '',
  cover_edp: '',
  cover_oil: '',
  cover_giftsets: '',
  cover_summer: '',
  cover_winter: '',
};

export const DEFAULT_ADMIN_PASSWORD = 'batttt';