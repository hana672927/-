export const translations = {
  ar: {
    welcome: "مرحباً بك في متجرنا الفاخر",
    shipping: "شحن مجاني لجميع الطلبات فوق $200 — توصيل لجميع أنحاء العالم",
    collection: "المجموعات",
    families: "عائلات العطور",
    about: "من نحن",
    contact: "تواصل معنا",
    heroSubtitle: "عطور نادرة مصنوعة يدوياً من أجود الزيوت والعود العالمي. عبير يروي كل حكاية.",
    heroTitle: "جوهر الفخامة",
    ourStory: "قصتنا",
    discover: "اكتشف المجموعة",
    search: "بحث...",
  },
  en: {
    welcome: "Welcome to Maison Verdor",
    shipping: "Complimentary shipping on all orders above $200 — Worldwide delivery",
    collection: "COLLECTION",
    families: "FAMILIES",
    about: "ABOUT",
    contact: "CONTACT",
    heroSubtitle: "Rare, hand-crafted fragrances composed from the world's finest oils and oud. A scent for every story.",
    heroTitle: "The Essence of Luxury",
    ourStory: "OUR STORY",
    discover: "DISCOVER THE COLLECTION",
    search: "Search...",
  }
};